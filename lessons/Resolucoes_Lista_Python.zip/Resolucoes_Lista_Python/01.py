numero = int(input('Informe um número inteiro: '))

for i in range(1, numero + 1):
  print(i, end=' ')

# Alternativamente...

print()

for i in range(numero):
  print(i + 1, end=' ')